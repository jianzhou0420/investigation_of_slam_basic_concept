classdef GPSMeasurementEdge < g2o.core.BaseUnaryEdge
   
    properties(Access = protected)
        
        xyOffset;
        
    end
    
    methods(Access = public)
    
        function this = GPSMeasurementEdge(xyOffset)
            this = this@g2o.core.BaseUnaryEdge(2);
            this.xyOffset = xyOffset;
        end
        
        function computeError(this)
            % Q1d start
            x = this.edgeVertices{1}.estimate(); % get the estimated state
            this.errorZ=x(1:2)-this.z; % compute the error of x and y
            % Q1d end
        end
        
        function linearizeOplus(this)
            % Q1d start
            this.J{1}=[1 0 0; 0 1 0]; % Jacobian matrix, GPS only have the info of x and y
            % Q1d end
        end
    end
end
