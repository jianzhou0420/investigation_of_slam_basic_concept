% This edge encodes a 3D range bearing measurement.
%
% The measurement is in spherical polar coordinates

% Jacobian from https://github.com/petercorke/robotics-toolbox-matlab/blob/master/RangeBearingSensor.m

classdef LandmarkRangeBearingEdge < g2o.core.BaseBinaryEdge
    
    methods(Access = public)
    
        function this = LandmarkRangeBearingEdge()
            this = this@g2o.core.BaseBinaryEdge(2);
        end
        
        function initialize(this)
            % Q2b start
            x = this.edgeVertices{1}.x; % get the state
            m = zeros(2, 1);            % landmark container
            m(1) = x(1) + this.z(1) * cos(this.z(2) + x(3)); % replace the base of the coordinates
            m(2) = x(2) + this.z(1) * sin(this.z(2) + x(3)); % replace the base of the coordinates
            % Q2b end
            this.edgeVertices{2}.setEstimate(m);
        end
        
        function computeError(this)
            % Q2b start
            x = this.edgeVertices{1}.estimate(); % state
            m = this.edgeVertices{2}.estimate(); % single observed landmark

            dx=m(1:2)-x(1:2); % coordinates of this landmark with respect to vehicle
            this.errorZ(1)=norm(dx)-this.z(1); % distance error
            this.errorZ(2)=g2o.stuff.normalize_theta(atan2(dx(2), dx(1)) - x(3) - this.z(2));% angle error
            % Q2b end

        end
        
        function linearizeOplus(this)
            % Q2b start
            x = this.edgeVertices{1}.estimate(); % state
            m = this.edgeVertices{2}.estimate(); % current landmark
            dx = m(1:2) - x(1:2);                 % x and y difference
            r = norm(dx);                         % distance

            this.J{1} = [-dx(1)/r,      -dx(2)/r,       0;
                         dx(2)/r^2,     -dx(1)/r^2,    -1];

            this.J{2} = - this.J{1}(1:2, 1:2);  % Jacobian matrix
                                                % derivation will show in
                                                % report
            % Q2b end
        end        
    end
end
