classdef CompassMeasurementEdge < g2o.core.BaseUnaryEdge
   
    % Q1c:
    % This implementation contains a bug. Identify the problem
    % and fix it as per the question.

    % Q1c answer:
    % the bug is failing to normalize the theta

    properties(Access = protected)
        
        compassAngularOffset;
        
    end
    
    methods(Access = public)
    
        function this = CompassMeasurementEdge(compassAngularOffset)
            this = this@g2o.core.BaseUnaryEdge(1);
            this.compassAngularOffset = compassAngularOffset;
        end
        
        function computeError(this)
            x = this.edgeVertices{1}.estimate(); % state
            this.errorZ = x(3) + this.compassAngularOffset - this.z; %calculate the error
            % Q1c start
            this.errorZ = g2o.stuff.normalize_theta(this.errorZ); % put it into the range of [-pi,pi]
            % Q1c end
        end
        
        function linearizeOplus(this)
            this.J{1} = [0 0 1]; % the compass only measure the angle of the vehicle
        end        
    end
end