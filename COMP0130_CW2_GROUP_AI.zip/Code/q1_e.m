% This script runs Q1(e)
clear
% Create the configuration object.
configuration = drivebot.SimulatorConfiguration();

% Since we are doing prediction and GPS, disable the SLAM sensor
configuration.enableGPS = true;
configuration.gpsPositionOffset=[0;0];

% Set to true for part ii
% configuration.enableCompass = true;

% Set up the simulator
simulator = drivebot.DriveBotSimulator(configuration, 'q1_e');

% Create the localization system
drivebotSLAMSystem = drivebot.DriveBotSLAMSystem(configuration);

% Q1(e)i:
% Use the method "setRecommendOptimizationPeriod" in DriveBotSLAMSystem
% to control the rate at which the optimizer runs

% This tells the SLAM system to do a very detailed check that the input
% appears to be correct but can make the code run slowly. Once you are
% confident your code is working safely, you can set this to false.
drivebotSLAMSystem.setValidateGraph(false);

% Run the main loop and correct results
drivebotSLAMSystem.setRecommendOptimizationPeriod(1);
results = minislam.mainLoop(simulator, drivebotSLAMSystem);

% Minimal output plots. For your answers, please provide titles and label
% the axes.

% Plot optimisation times
title('Simulation')
xlabel('x')
ylabel('y')

% Plot optimisation times
minislam.graphics.FigureManager.getFigure('Optimization times');
clf
plot(results{1}.optimizationTimes, '*')
title('Optimization times')
xlabel('Timestep')
ylabel('Time/s')
hold on

% Plot the error curves
minislam.graphics.FigureManager.getFigure('Errors');
clf
errors = results{1}.vehicleStateHistory'-results{1}.vehicleTrueStateHistory';
% wrap theta in [-pi, pi] in case any numerial fault in code
errors(:,3) = g2o.stuff.normalize_thetas(errors(:,3));
plot(errors)
title('Errors')
xlabel('Timestep')
ylabel('Error')
legend('Error of x','Error of y', 'Error of theta')

% Plot covariance
minislam.graphics.FigureManager.getFigure('Vehicle Covariances');
clf
plot(results{1}.vehicleCovarianceHistory')
title('Vehicle Covariances')
legend('covariance in x', 'covariance in y', 'covariance in theta')
xlabel('Timestep')
ylabel('covariance')
hold on

% Plot chi2 values
minislam.graphics.FigureManager.getFigure('chi2');
clf

for i=1:1:length(results{1}.chi2History)
if results{1}.chi2History(i)<=1e-5
    results{1}.chi2History(i)=0;
end
end

plot(log(results{1}.chi2History))
title('chi2')
xlabel('TimeStep')
ylabel('chi2 number')
hold on


