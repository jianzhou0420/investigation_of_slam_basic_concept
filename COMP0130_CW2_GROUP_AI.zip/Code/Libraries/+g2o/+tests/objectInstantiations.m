% Basic object instantation tests. Just create a bunch of objects.
% Rules out daft syntax errors

baseVertex = g2o.BaseVertex();